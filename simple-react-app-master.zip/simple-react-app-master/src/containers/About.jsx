import React from 'react';

const About = () => (
  <div>
    <h2>About Page</h2>
  </div>
);

export default About;
