import React from 'react';

const Home = () => (
  <div>
    <h2>Home Page</h2>
  </div>
);

export default Home;
